from django.shortcuts import render

def randomchoice(request):
    return render(request, 'index.html')